@parent my-app
@module {can.Component} my-app/visualization <app-visual>

A short description of the app-visual component

@signature `<app-visual>`

@body

## Use

